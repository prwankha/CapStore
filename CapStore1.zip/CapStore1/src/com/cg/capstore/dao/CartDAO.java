package com.cg.capstore.dao;

public interface CartDAO {
	
}