package com.cg.capstore.dao;

public class MerchantDAOImpl {

}
